/* automatically generated. DO NOT EDIT. */
#include <linux/drbd_config.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: bbadddd7bad33396ebb8c0c12da9aab594d00c4e drbd/Makefile-2.6"
		" build by phil@fat-tyre, 2009-04-01 10:29:21";
}
